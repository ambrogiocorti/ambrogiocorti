// 1. Inizializzazione del menu contestuale
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "ccna-finder-pro",
    title: "Verifica terminologia", 
    contexts: ["selection"]
  });
});

// Gestore degli eventi di click
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "ccna-finder-pro") {
    const selezioneText = info.selectionText.trim();
    const urlDatabase = "https://itexamanswers.net/ccna-1-v7-0-final-exam-answers-full-introduction-to-networks.html";

    try {
      const configTraduzione = await normalizzaTesto(selezioneText);
      
      const response = await fetch(urlDatabase);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const htmlText = await response.text();

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: elaboraERenderizzaMousseMimeticoDinamico,
        args: [htmlText, configTraduzione.testoInglese, configTraduzione.linguaRilevata]
      });

    } catch (error) {
      console.error(error);
    }
  }
});

async function normalizzaTesto(testo) {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(testo)}`;
    const res = await fetch(url);
    const json = await res.json();
    let testoTradotto = "";
    let linguaRilevata = "en";
    if (json) {
      if (json[2]) linguaRilevata = json[2];
      if (json[0]) {
        json[0].forEach(linea => { if (linea[0]) testoTradotto += linea[0]; });
      }
    }
    return { testoInglese: testoTradotto.trim(), linguaRilevata: linguaRilevata };
  } catch (e) {
    return { testoInglese: testo, linguaRilevata: "en" };
  }
}

// UI SCRIPT AVANZATO: Algoritmo anti-falsi positivi con ripristino logica immagini
async function elaboraERenderizzaMousseMimeticoDinamico(htmlText, domandaInglese, linguaOriginale) {
  if (!window.hasOwnProperty('lastMouseX')) {
    window.lastMouseX = 0;
    window.lastMouseY = 0;
    document.addEventListener('mousemove', (e) => {
      window.lastMouseX = e.clientX;
      window.lastMouseY = e.clientY;
    }, { passive: true });
  }

  async function traduciInPagina(testo, aLingua) {
    if (!testo.trim() || aLingua !== "it") return testo;
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=it&dt=t&q=${encodeURIComponent(testo)}`;
      const response = await fetch(url);
      const json = await response.json();
      let res = "";
      if (json && json[0]) json[0].forEach(l => { if (l[0]) res += l[0]; });
      return res.trim();
    } catch (e) { return testo; }
  }

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlText, "text/html");
    const elementi = doc.querySelectorAll("p, li, strong");

    let elementoMigliore = null;
    let punteggioMassimo = -9999;

    const ottieniToken = (str) => {
      return str.toLowerCase()
        .replace(/[^a-z0-9 ]/g, "")
        .split(/\s+/)
        .filter(p => p.length > 2);
    };

    const paroleTarget = ottieniToken(domandaInglese);

    for (let i = 0; i < elementi.length; i++) {
      const testoElemento = elementi[i].innerText.trim();
      if (testoElemento.length < 20 || testoElemento.length > 350) continue;

      const paroleElemento = ottieniToken(testoElemento);
      
      let punteggioCorrente = 0;
      let matchTrovati = 0;

      paroleTarget.forEach(p => {
        if (paroleElemento.includes(p)) {
          matchTrovati++;
          if (/\d/.test(p) || p.length > 5) {
            punteggioCorrente += 3;
          } else {
            punteggioCorrente += 1;
          }
        }
      });

      const differenzaParole = Math.abs(paroleElemento.length - paroleTarget.length);
      punteggioCorrente -= (differenzaParole * 0.5);

      if (matchTrovati >= Math.ceil(paroleTarget.length * 0.3)) {
        if (punteggioCorrente > punteggioMassimo) {
          punteggioMassimo = punteggioCorrente;
          elementoMigliore = elementi[i];
        }
      }
    }

    if (elementoMigliore) {
      let risposteCorretteContenuto = [];
      let prossimoElemento = elementoMigliore.nextElementSibling;
      let contatore = 0;
      let immaginiDomandaTrovate = [];

      while (prossimoElemento && contatore < 12) {
        const testoGrezzo = prossimoElemento.innerText.trim();
        if (prossimoElemento.tagName === "HR" || testoGrezzo.includes("⭐") || /^\d+\.\s/.test(testoGrezzo)) break;

        const testoLower = testoGrezzo.toLowerCase();
        if (testoLower.startsWith("explanation:") || testoLower.startsWith("explain:")) {
          prossimoElemento = prossimoElemento.nextElementSibling;
          contatore++;
          continue;
        }

        const imgNodo = prossimoElemento.querySelector("img") || (prossimoElemento.tagName === "IMG" ? prossimoElemento : null);
        if (imgNodo && imgNodo.getAttribute("src")) {
          const srcTrovato = imgNodo.getAttribute("src");
          if (!immaginiDomandaTrovate.includes(srcTrovato)) {
            immaginiDomandaTrovate.push(srcTrovato);
          }
        }

        const sottoElementi = prossimoElemento.querySelectorAll("*");
        const tuttiINodi = [prossimoElemento, ...sottoElementi];

        tuttiINodi.forEach(nodo => {
          if (nodo.style && nodo.style.color) {
            const colore = nodo.style.color.toLowerCase();
            if (colore.includes("255, 0, 0") || colore.includes("255,0,0") || colore.includes("ff0000") || colore === "red") {
              const testoRisposta = nodo.innerText.trim();
              if (testoRisposta && !testoRisposta.toLowerCase().startsWith("explanation") && !risposteCorretteContenuto.some(item => item.value === testoRisposta)) {
                risposteCorretteContenuto.push({ type: "text", value: testoRisposta });
              }
            }
          }
        });
        prossimoElemento = prossimoElemento.nextElementSibling;
        contatore++;
      }

      // Se non c'è testo rosso ma ci sono immagini nel blocco domanda
      if (risposteCorretteContenuto.length === 0 && immaginiDomandaTrovate.length > 0) {
        if (immaginiDomandaTrovate.length >= 2) {
          // Isola e mostra unicamente la seconda immagine
          risposteCorretteContenuto.push({ type: "image", value: immaginiDomandaTrovate[1] });
        } else {
          risposteCorretteContenuto.push({ type: "image", value: immaginiDomandaTrovate[0] });
        }
      }

      let elementiDaRenderizzare = [];
      for (let item of risposteCorretteContenuto) {
        if (item.type === "text") {
          const testoElaborato = (linguaOriginale === "it") ? await traduciInPagina(item.value, "it") : item.value;
          elementiDaRenderizzare.push({ type: "text", value: testoElaborato });
        } else if (item.type === "image") {
          elementiDaRenderizzare.push(item);
        }
      }

      if (elementiDaRenderizzare.length > 0) {
        const divMouse = document.createElement("div");
        divMouse.id = "ccna-mouse-stealth";
        
        Object.assign(divMouse.style, {
          position: "fixed",
          left: `${window.lastMouseX + 12}px`,
          top: `${window.lastMouseY + 12}px`,
          backgroundColor: "#ffffff",
          color: "#000000",
          fontFamily: "Times New Roman, serif",
          fontSize: "11px",
          padding: "5px 7px",
          border: "1px solid #d3d3d3",
          borderRadius: "2px",
          zIndex: "2147483647",
          pointerEvents: "none",
          display: "flex",
          flexDirection: "column",
          gap: "4px"
        });

        elementiDaRenderizzare.forEach(item => {
          if (item.type === "text") {
            const containerTesto = document.createElement("div");
            containerTesto.innerText = item.value;
            divMouse.appendChild(containerTesto);
          } else if (item.type === "image") {
            const tagImmagine = document.createElement("img");
            tagImmagine.src = item.value;
            Object.assign(tagImmagine.style, {
              maxHeight: "220px",
              maxWidth: "450px",
              display: "block",
              border: "1px solid #dddddd",
              backgroundColor: "#ffffff"
            });
            divMouse.appendChild(tagImmagine);
          }
        });

        document.body.appendChild(divMouse);

        setTimeout(() => {
          if (divMouse) divMouse.remove();
        }, 3500);
      }
    }
  } catch (err) {
    console.error(err);
  }
}