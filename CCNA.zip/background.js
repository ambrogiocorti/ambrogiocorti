// 1. Crea la voce nel menu del click destro
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "cercaRispostaCCNA",
    title: "Trova risposta su ITExamAnswers",
    contexts: ["selection"]
  });
});

// Funzione di supporto per tradurre il testo in inglese usando Google Translate
async function traduciInInglese(testo) {
  try {
    // Usiamo l'endpoint di Google Translate (asincrono e veloce)
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(testo)}`;
    const response = await fetch(url);
    const json = await response.json();
    
    // Ricostruiamo la frase tradotta dal pattern di risposta di Google
    let testoTradotto = "";
    if (json && json[0]) {
      json[0].forEach(linea => {
        if (linea[0]) testoTradotto += linea[0];
      });
    }
    return testoTradotto.trim();
  } catch (err) {
    console.error("Errore di traduzione, uso il testo originale:", err);
    return testo; // Fallback: se la traduzione fallisce, usa il testo originale
  }
}

// 2. Gestisce l'evento di click
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "cercaRispostaCCNA") {
    const testoSelezionato = info.selectionText;
    const urlPagina = "https://itexamanswers.net/ccna-1-v7-0-final-exam-answers-full-introduction-to-networks.html";

    try {
      // TRADUZIONE: Traduciamo sempre in inglese in background
      const domandaInInglese = await traduciInInglese(testoSelezionato);
      
      // Scarichiamo la pagina delle risposte
      const response = await fetch(urlPagina);
      const htmlText = await response.text();

      // Passiamo l'HTML, la domanda originale e quella tradotta alla pagina per l'analisi
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: analizzaEVisualizzaRisposta,
        args: [htmlText, domandaInInglese, testoSelezionato]
      });

    } catch (networkError) {
      console.error(networkError);
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (err) => alert("Errore di rete: " + err),
        args: [networkError.message]
      });
    }
  }
});

// 3. Questa funzione riceve l'HTML ed esegue l'analisi
function analizzaEVisualizzaRisposta(htmlText, domandaInglese, domandaOriginale) {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlText, "text/html");

    const elementi = doc.querySelectorAll("p, li, strong");
    let elementoDomandaTrovato = null;

    // Pulizia del testo per il confronto (rimuove punteggiatura, spazi e maiuscole)
    const pulisciTesto = (t) => t.toLowerCase().replace(/[^a-z0-9]/g, "");
    const domandaPulita = pulisciTesto(domandaInglese);

    // Cerca la domanda in inglese nella pagina
    for (let i = 0; i < elementi.length; i++) {
      const testoElemento = elementi[i].innerText;
      if (pulisciTesto(testoElemento).includes(domandaPulita) && domandaPulita.length > 8) {
        elementoDomandaTrovato = elementi[i];
        break;
      }
    }

    if (elementoDomandaTrovato) {
      let risposteCorrette = [];
      let spiegazione = "";
      
      let prossimoElemento = elementoDomandaTrovato.nextElementSibling;
      let contatore = 0;

      // Scansiona i tag successivi, MA si ferma rigidamente alla domanda successiva
      while (prossimoElemento && contatore < 12) {
        const testoGrezzo = prossimoElemento.innerText.trim();
        const testoLower = testoGrezzo.toLowerCase();

        // BLOCCO DI SICUREZZA: Se incontriamo elementi che indicano una NUOVA domanda, ci fermiamo subito!
        if (
          prossimoElemento.tagName === "HR" || 
          testoGrezzo.includes("⭐") || 
          /^\d+\.\s/.test(testoGrezzo) || // Corrisponde a numeri seguiti da punto all'inizio (es: "2. ", "15. ")
          (testoGrezzo.includes("?") && contatore > 3) // Se c'è un punto di domanda dopo aver già scorso un po' di righe
        ) {
          break;
        }

        // Cattura la spiegazione specifica di QUESTA domanda
        if (testoLower.startsWith("explanation:") || testoLower.startsWith("explain:")) {
          spiegazione = testoGrezzo;
        }

        // Cerca il testo colorato di rosso all'interno del blocco opzioni
        const sottoElementi = prossimoElemento.querySelectorAll("*");
        const tuttiINodi = [prossimoElemento, ...sottoElementi];

        tuttiINodi.forEach(nodo => {
          if (nodo.style && nodo.style.color) {
            const colore = nodo.style.color.toLowerCase();
            
            if (colore.includes("255, 0, 0") || colore.includes("255,0,0") || colore.includes("ff0000") || colore === "red") {
              const testoRisposta = nodo.innerText.trim();
              
              // Evitiamo di salvare stringhe vuote o la spiegazione stessa se colorata di rosso
              if (testoRisposta && !risposteCorrette.includes(testoRisposta) && !testoRisposta.toLowerCase().startsWith("explanation")) {
                risposteCorrette.push(testoRisposta);
              }
            }
          }
        });

        prossimoElemento = prossimoElemento.nextElementSibling;
        contatore++;
      }

      // Mostra il responso finale all'utente
      if (risposteCorrette.length > 0) {
        let messaggio = `🔍 Domanda cercata (Inglese):\n"${domandaInglese}"\n\n🎯 Risposta/e Corretta/e:\n`;
        risposteCorrette.forEach((resp, index) => {
          messaggio += `👉 ${resp}\n`;
        });
        if (spiegazione) {
          messaggio += `\n💡 ${spiegazione}`;
        }
        alert(messaggio);
      } else {
        alert(`Domanda trovata, ma non sono riuscito a isolare il testo rosso delle risposte.\n\nEcco il blocco originale:\n${elementoDomandaTrovato.innerText}`);
      }

    } else {
      alert(`Non ho trovato questa domanda su ITExamAnswers.\n\nTesto cercato in inglese:\n"${domandaInglese}"\n\nProva a selezionare una porzione di testo più breve.`);
    }

  } catch (error) {
    console.error(error);
    alert("Errore durante l'analisi della pagina: " + error.message);
  }
}